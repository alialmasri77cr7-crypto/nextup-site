NEXTUP WEBSITE

Files:
- index.html: your complete mobile-friendly black-and-white website.

To publish free with GitHub Pages:
1. Sign in to GitHub (ask a parent/guardian for help if needed).
2. Create a PUBLIC repository named nextup-site.
3. Open the repository, choose Add file > Upload files.
4. Upload index.html (not the ZIP file), then commit the changes.
5. Open Settings > Pages.
6. Under Build and deployment, choose Deploy from a branch.
7. Select branch main and folder /(root), then Save.
8. Wait a few minutes and open the site URL shown in Pages settings.

Important: A public website can be seen by anyone. Do not put your home address,
phone number, school, passwords, or other private information on it. If you are
under 18, ask a parent/guardian to help with accounts, payments, and any business
arrangements. This is a static website; it does not take payments or collect emails.
